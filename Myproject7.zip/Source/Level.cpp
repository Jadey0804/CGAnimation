﻿#include "Level.h"
#include <fstream>
#include <sstream>

#include <malloc.h>   // _aligned_malloc / _aligned_free


AnimatedModel* Level::allocAlignedAnim()
{
    void* mem = _aligned_malloc(sizeof(AnimatedModel), 64);
    if (!mem) return nullptr;
    return new (mem) AnimatedModel();
}

void Level::freeAlignedAnim(AnimatedModel* p)
{
    if (!p) return;
    p->~AnimatedModel();
    _aligned_free(p);
}




void Level::init(Core* core, PSOManager* psos, Shaders* shaders, TextureManager* textures,
    Plane* plane, Skybox* skybox)
{
    m_core = core;
    m_psos = psos;
    m_shaders = shaders;
    m_textures = textures;
    m_plane = plane;
    m_skybox = skybox;

    // 初始化草地系统
    m_grass = new Grass();
    m_grass->init(core, psos, shaders, textures);
}

void Level::clear()
{
    m_objects.clear();
    m_objectToAnimIndex.clear();
    m_animEntries.clear();

    for (auto& kv : m_staticCache) delete kv.second;
    for (auto& kv : m_animCache) freeAlignedAnim(kv.second);

    m_staticCache.clear();
    m_animCache.clear();

    // 清理草地
    if (m_grass)
    {
        m_grass->clear();
    }
}

StaticModel* Level::getOrLoadStatic(const std::string& path)
{
    auto it = m_staticCache.find(path);
    if (it != m_staticCache.end()) return it->second;

    auto* m = new StaticModel();
    m->load(m_core, path, m_shaders, m_psos);
    m_staticCache[path] = m;
    return m;
}

AnimatedModel* Level::getOrLoadAnim(const std::string& path)
{
    auto it = m_animCache.find(path);
    if (it != m_animCache.end()) return it->second;

    auto* m = allocAlignedAnim();
    m->load(m_core, path, m_psos, m_shaders);

    if (!m->textureFilenames.empty())
    {
        for (auto& s : m->textureFilenames)
        {
            if (s.empty())
                s = "Models/Textures/T-rex_Base_Color_alb.png";
            m_textures->getTextureIndex(s);
        }
    }

    m_animCache[path] = m;
    return m;
}

bool Level::loadFromFile(const std::string& levelPath)
{
    std::ifstream f(levelPath);
    if (!f.is_open()) return false;

    m_objects.clear();
    m_objectToAnimIndex.clear();
    m_animEntries.clear();

    // 清理旧的草地实例
    if (m_grass)
    {
        m_grass->clear();
    }

    std::string line;
    while (std::getline(f, line))
    {
        LevelObject obj;
        if (!parseLine(line, obj)) continue;

        int animIndex = -1;

        if (obj.type == LevelObjType::Static)
        {
            (void)getOrLoadStatic(obj.modelPath);
        }
        else if (obj.type == LevelObjType::Anim)
        {
            AnimEntry e;
            e.model = getOrLoadAnim(obj.modelPath);

            if (!obj.animName.empty())
            {
                e.animName = obj.animName;
            }
            else if (!e.model->animation.animations.empty())
            {
                e.animName = e.model->animation.animations.begin()->first;
            }
            else
            {
                e.animName = "";
            }

            e.instance.init(&e.model->animation, 0);
            e.inited = true;

            animIndex = (int)m_animEntries.size();
            m_animEntries.push_back(std::move(e));
        }
        else if (obj.type == LevelObjType::Grass)
        {
            // 在指定位置散布草地
            if (m_grass)
            {
                m_grass->scatterGrass(obj.pos, obj.grassRadius, obj.grassCount,
                                      obj.scale.x, obj.scale.y);  // scale.x=minScale, scale.y=maxScale
            }
            // GRASS 类型不加入 m_objects，直接处理
            continue;
        }

        m_objects.push_back(std::move(obj));
        m_objectToAnimIndex.push_back(animIndex);
    }

    return true;
}

void Level::update(float dt)
{
    for (auto& e : m_animEntries)
    {
        if (!e.inited) continue;
        if (e.animName.empty()) continue;

        if (!e.model->animation.hasAnimation(e.animName)) continue;

        e.instance.update(e.animName, dt);

        if (e.instance.animationFinished())
        {
            e.instance.resetAnimationTime();
        }
    }
}

void Level::draw(Matrix& vp, Matrix& skyVP, float time, const Vec3& cameraPos,
                 const Vec3& cameraRight, const Vec3& cameraUp)
{
    m_shaders->updateConstantVS("StaticModelUntextured", "staticMeshBuffer", "VP", &vp);
    m_shaders->updateConstantVS("AnimatedTextured", "staticMeshBuffer", "VP", &vp);

    // 先画 plane
    if (m_plane)
    {
        m_plane->draw(m_core, m_psos, m_shaders, m_textures, vp);
    }

    // 再画静态/动画对象
    for (size_t i = 0; i < m_objects.size(); i++)
    {
        const LevelObject& o = m_objects[i];

        if (o.type == LevelObjType::Static)
        {
            StaticModel* m = getOrLoadStatic(o.modelPath);
            Matrix W = buildWorld(o);
            m->updateWorld(m_shaders, W);
            m->draw(m_core, m_psos, m_shaders, vp);
        }
        else if (o.type == LevelObjType::Anim)
        {
            int idx = m_objectToAnimIndex[i];
            if (idx < 0 || idx >= (int)m_animEntries.size()) continue;

            AnimEntry& e = m_animEntries[idx];
            Matrix W = buildWorld(o);

            e.model->draw(m_core, m_psos, m_shaders, m_textures, &e.instance, vp, W);
        }
    }

    // 画草地（在其他物体之后，skybox之前）
    if (m_grass)
    {
        m_grass->draw(m_core, m_psos, m_shaders, m_textures, vp, cameraPos, cameraRight, cameraUp);
    }

    // 最后画 skybox
    if (m_skybox)
    {
        Matrix W = Matrix::translation(cameraPos);
        m_skybox->draw(m_core, m_psos, m_shaders, m_textures, time, &W, &skyVP);
    }
}

bool Level::parseLine(const std::string& line, LevelObject& outObj)
{
    std::string s = line;
    if (s.empty()) return false;

    bool allSpace = true;
    for (char c : s) { if (!isspace((unsigned char)c)) { allSpace = false; break; } }
    if (allSpace) return false;

    size_t first = s.find_first_not_of(" \t\r\n");
    if (first == std::string::npos) return false;
    if (s[first] == '#') return false;

    std::istringstream iss(s);

    std::string type;
    iss >> type;
    if (!iss) return false;

    auto toType = [&](const std::string& t) -> LevelObjType
        {
            if (t == "STATIC") return LevelObjType::Static;
            if (t == "ANIM")   return LevelObjType::Anim;
            if (t == "PLANE")  return LevelObjType::Plane;
            if (t == "SKYBOX") return LevelObjType::Skybox;
            if (t == "GRASS")  return LevelObjType::Grass;
            return LevelObjType::Static;
        };

    outObj.type = toType(type);

    if (outObj.type == LevelObjType::Grass)
    {
        // GRASS 格式: GRASS px py pz count radius minScale maxScale
        iss >> outObj.pos.x >> outObj.pos.y >> outObj.pos.z;
        iss >> outObj.grassCount >> outObj.grassRadius;
        iss >> outObj.scale.x >> outObj.scale.y;  // minScale, maxScale
        return true;
    }

    // 统一格式：
    // type model px py pz sx sy sz rx ry rz [animName]
    iss >> outObj.modelPath;
    iss >> outObj.pos.x >> outObj.pos.y >> outObj.pos.z;
    iss >> outObj.scale.x >> outObj.scale.y >> outObj.scale.z;
    iss >> outObj.rotDeg.x >> outObj.rotDeg.y >> outObj.rotDeg.z;

    if (outObj.type == LevelObjType::Anim)
    {
        iss >> outObj.animName;
    }

    return true;
}

Matrix Level::buildWorld(const LevelObject& o)
{
    Matrix S = Matrix::scaling(o.scale);
    Matrix Rx = Matrix::rotateX(degToRad(o.rotDeg.x));
    Matrix Ry = Matrix::rotateY(degToRad(o.rotDeg.y));
    Matrix Rz = Matrix::rotateZ(degToRad(o.rotDeg.z));
    Matrix T = Matrix::translation(o.pos);

    Matrix R = (Rx * Ry) * Rz;
    return (S * R) * T;
}
